import json
from random import randint
from twilio.rest import Client
def lambda_handler(event, context):
    http_method=event['httpMethod']
    if http_method=="POST":
        body=json.loads(event['body'])
        account_sid=body['account_sid']
        auth_token=body['auth_token']
        sender=body['sender']
        reciever=body['reciever']
        eventtype=body['eventtype']
        if eventtype=='phnumverify':
            otp=phnumverify(account_sid,auth_token,sender,reciever)
            return {
                'statusCode': 200,
                'body': json.dumps(otp)
                }
        elif eventtype=='forgotpwd':
            otp=forgotpwd(account_sid,auth_token,sender,reciever)
            return {
                'statusCode': 200,
                'body': json.dumps(otp)
                }
        elif eventtype=='successfulbooking':
            successfulbooking(account_sid,auth_token,sender,reciever)
            return {
                'statusCode': 200,
                'body': json.dumps("Successfully booked!")
                }
        elif eventtype=='cancelbooking':
            cancelbooking(account_sid,auth_token,sender,reciever)
            return {
                'statusCode': 200,
                'body': json.dumps("Successfully cancelled")
                } 
    else:
            return {
                'statusCode': 403,
                'body': json.dumps("Denied")
                } 

def phnumverify(account_sid,auth_token,sender,reciever):
    detail=randint(10**5, (10**6)-1)
    client = Client(account_sid, auth_token)
    body1="Your OTP to register is "
    body2=body1+str(detail)
    message = client.messages.create(
                body=body2,
                from_=sender,
                to=reciever,
                )
    return detail
    
def forgotpwd(account_sid,auth_token,sender,reciever):
    detail=randint(10**5, (10**6)-1)
    client = Client(account_sid, auth_token)
    body1="Your OTP to reset password is "
    body2=body1+str(detail)
    message = client.messages.create(
                body=body2,
                from_=sender,
                to=reciever,
                )
    return detail
    
def successfulbooking(account_sid,auth_token,sender,reciever):
    client = Client(account_sid, auth_token)
    body1="Hurray! You have succesfully booked a room :)"
    message = client.messages.create(
                body=body1,
                from_=sender,
                to=reciever,
                )
    return message
    
def cancelbooking(account_sid,auth_token,sender,reciever):
    client = Client(account_sid, auth_token)
    body1="You have succesfully cancelled your booking :)"
    message = client.messages.create(
                body=body1,
                from_=sender,
                to=reciever,
                )
    return message

