
export class BookingPost {
    id: any;
    uId:any;
    rId:any;
    currentStatus:any;
    bookedDays:any;
    bookedFrom: any;
    bookedTo: any;
    costPerDay:any;
    constructor() { }
}
