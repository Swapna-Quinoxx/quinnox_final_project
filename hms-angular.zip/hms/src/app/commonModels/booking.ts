export class Booking {
    id:any;
    rId:any;
    fromDate: any;
    toDate: any;
    room: string;
    bookedDays:any;
    costPerDay:any;
    constructor() { }
  }
