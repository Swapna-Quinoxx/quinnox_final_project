export class User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  mobileNum: string;
  password: string;
  aadhar: string;
  wallet: number = 0;
  isAdmin: boolean;

  constructor() { }
}
