import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/services/api.service';
import { CommonServiceService } from '../../services/common-service.service';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-my-booking',
  templateUrl: './my-booking.component.html',
  styleUrls: ['./my-booking.component.css']
})
export class MyBookingComponent implements OnInit {
  cancelConfirm: boolean = false;
  constructor(
    private service: ApiService,
    private commonService: CommonServiceService,
    private datePipe: DatePipe,
    private router: Router
  ) { }
  msg: string = '';
  data: any;
  room = {
    id: '101',
    bookings: [
      {
        bookingStatus: false
      }
    ]
  };
  userBookings = [];
  otpData =
    {
      "account_sid": "twilio_sid",
      "auth_token": "twilio_auth",
      "sender": "twilio_ph_num",
      "reciever": "reciever_phnum",
      "eventtype": "cancelbooking"
    }
  ngOnInit(): void {
    this.userBookings = []
    this.cancelConfirm = false;
    this.data = this.commonService.user;
    this.service.getBookings().subscribe(res => {
      res.map(item => {
        let fromDate = this.datePipe.transform(item.bookedFrom, 'yyyy-MM-dd');
        let currDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
        let delStatus = false;
        let bookingStatus = 'Expired'
        if (fromDate > currDate && item.currentStatus && item.uId === this.commonService.user.id) {
          delStatus = true;
          bookingStatus = "Active"
        }
        if (fromDate > currDate && !item.currentStatus && item.uId === this.commonService.user.id) {
          delStatus = false;
          bookingStatus = "Cancelled"
        }
        item.bookingStatus = bookingStatus;
        item.delStatus = delStatus
        if (item.uId == this.commonService.user.id) {
          this.userBookings.push(item)
        }
      });
    });
  }
  cancelBooking(bookingId) {
    this.cancelConfirm = confirm('Are you sure that you want to cancel?');
    if (this.cancelConfirm === true) {
      this.service.getBookingById(bookingId).subscribe(res => {
        res.currentStatus = false;
        this.service.cancelUpdateBooking(res).then(
          data => {
            this.service.getOtp(this.otpData).then(
              data => {
                console.log(data)
                this.ngOnInit()
              },
              error => {
                this.ngOnInit()
                console.log(error)
              }
            );
          }
        );
        this.room.id = res.rId;
        this.data.wallet = this.data.wallet + (res.bookedDays * res.costPerDay);
        this.service.updateWallet(this.data);
        this.service.cancelUpdateRoom(this.room);
      });
    }
  }
}
