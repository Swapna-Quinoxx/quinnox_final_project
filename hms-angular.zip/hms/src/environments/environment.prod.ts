export const environment = {
  production: true,
  //baseUrl: 'http://localhost:8080',
  baseUrl: 'http://ec2-52-66-148-195.ap-south-1.compute.amazonaws.com:8080'
};
